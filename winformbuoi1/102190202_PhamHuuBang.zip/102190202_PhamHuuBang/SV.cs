﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitapquanlysinhvien
{
    class SV
    {
        public int MSSV { get; set; }//automatic propety//o trong co truong privat tuong ung voi property
        public string Name { get; set; }
        public bool Gender { get; set; }
        public DateTime NS { get; set; }
        public int Id_lop { get; set; }
    }
}
