﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitapquanlysinhvien
{
    class LopSh
    {
        public int Id_lop { get; set; }
        public string NameLop { get; set; }
    }
}
